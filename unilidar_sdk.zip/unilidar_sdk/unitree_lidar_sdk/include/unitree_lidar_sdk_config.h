#define unitree_lidar_sdk_VERSION "1.0.16"
#define unitree_lidar_sdk_VERSION_MAJOR 1
#define unitree_lidar_sdk_VERSION_MINOR 0
#define unitree_lidar_sdk_VERSION_PATCH 16
