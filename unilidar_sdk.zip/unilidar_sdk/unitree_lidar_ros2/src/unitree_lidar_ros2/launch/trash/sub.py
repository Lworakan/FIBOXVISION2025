import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2, Imu
import std_msgs.msg
import os

class LidarDataLogger(Node):
    def __init__(self):
        super().__init__('lidar_data_logger')

        # Create subscribers for point cloud and IMU data
        self.point_cloud_subscriber = self.create_subscription(
            PointCloud2,
            '/unilidar/cloud',  # The topic name for lidar point cloud data
            self.point_cloud_callback,
            10
        )

        self.imu_subscriber = self.create_subscription(
            Imu,
            '/unilidar/imu',  # The topic name for IMU data
            self.imu_callback,
            10
        )

        # Open the log file in append mode
        self.log_file = open("./lidar_data_logv2.txt", "a")

    def point_cloud_callback(self, msg):
        # Extract and log point cloud data (you can log more detailed data if needed)
        self.get_logger().info('Received point cloud data\n')
        self.get_logger().info(f"PointCloud2: {msg.data}.\n")
        # Here, we log the size of the point cloud (you can log more if needed)
        #self.log_file.write(f"PointCloud2: {len(msg.data)} bytes\n")
        self.log_file.write(f"PointCloud2: {msg.data}.\n")
        self.log_file.write(f"---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n")

    def imu_callback(self, msg):
        # Extract and log IMU data
        #self.get_logger().info('Received IMU data')
        #self.get_logger().info(f'IMU: Orientation {msg.orientation} Angular Velocity {msg.angular_velocity}\n')
        # Log the IMU orientation and angular velocity
        self.log_file.write(f"IMU: Orientation {msg.orientation} Angular Velocity {msg.angular_velocity}\n")

    def __del__(self):
        # Close the log file when the node is destroyed
        self.log_file.close()

def main(args=None):
    rclpy.init(args=args)

    lidar_data_logger = LidarDataLogger()

    rclpy.spin(lidar_data_logger)

    lidar_data_logger.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

# cd /src/unitree_lidar_ros2/launch