import rclpy
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2 as pc2

def main():
    rclpy.init()
    node = rclpy.create_node('point_cloud_reader')
    
    # Example: Imagine 'msg' is the received PointCloud2 message
    # Here we simulate receiving a PointCloud2 message
    msg = PointCloud2()  # This would normally come from a subscriber callback

    # Read points
    for point in pc2.read_points(msg, field_names=("x", "y", "z"), skip_nans=True):
        print(f"Point: x={point[0]}, y={point[1]}, z={point[2]}")

if __name__ == '__main__':
    main()
