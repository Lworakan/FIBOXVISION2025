import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import json

with open("./lidar_pointcloud_log.json", "r") as file:
    pc = json.load(file)
    data = pc['data']
    print(len(data))
    print(data[0])
    hope = []
    x = []
    y = []
    z = []
    for i in range(len(data)):
        hope.append([data[i]["x"] , data[i]["y"], data[i]["z"]])
        x.append(data[i]["x"])
        y.append(data[i]["y"])
        z.append(data[i]["z"])

    print(hope[0])
    print(len(hope))


    lidar_data = np.array(hope)
    x =  np.array(x) * 10
    y =  np.array(y) * 10
    z =  np.array(z) * 10

    print(min(x))
    print(min(y))
    print(min(z))
    print(max(x))
    print(max(y))
    print(max(z))
    distances = np.sqrt(x**2 + y**2 + z**2)

    # Create a figure and 3D axes object
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    # Scatter plot with color based on distance from the origin
    scatter = ax.scatter(x, y, z, c=distances, cmap='plasma', marker='o')


    # Set axis limits (adjust these for better scaling)
    # -23.628101348876953
    # -69.27946090698242
    # 0.4449429363012314
    # 64.44496154785156
    # 43.61292839050293
    # 30.267457962036133


    ax.set_xlim([-24, 70])
    ax.set_ylim([-70, 45])
    ax.set_zlim([-1, 32])

    # Add colorbar to indicate the distance scale
    fig.colorbar(scatter, ax=ax, label='Distance from Origin')

    # Set labels for the axes
    ax.set_xlabel('X Label')
    ax.set_ylabel('Y Label')
    ax.set_zlabel('Z Label')

    # Show the plot
    plt.show()


# # Example: Your lidar point cloud data (replace with actual data)
# lidar_data = np.array([
#     [0.1, 0.2, 0.3],
#     [0.4, 0.5, 0.6],
#     [0.7, 0.8, 0.9],
#     # Add more points here...
# ])

# # Extract the x, y, z coordinates
# x = lidar_data[:, 0]
# y = lidar_data[:, 1]
# z = lidar_data[:, 2]

# # Create a figure and 3D axes object
# fig = plt.figure()
# ax = fig.add_subplot(111, projection='3d')

# # Scatter plot of the 3D lidar points
# ax.scatter(x, y, z, c='g', marker='o')

# # Set labels for the axes
# ax.set_xlabel('X Label')
# ax.set_ylabel('Y Label')
# ax.set_zlabel('Z Label')

# # Show the plot
# plt.show()
