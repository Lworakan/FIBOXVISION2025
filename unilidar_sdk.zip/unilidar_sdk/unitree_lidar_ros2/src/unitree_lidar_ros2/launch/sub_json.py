import rclpy
from rclpy.node import Node
import json
from sensor_msgs.msg import PointCloud2, Imu
from sensor_msgs_py import point_cloud2 as pc2
import numpy as np
import time

class LidarDataLogger(Node):
    def __init__(self):
        super().__init__('lidar_data_logger')

        # Create subscribers for point cloud and IMU data
        self.point_cloud_subscriber = self.create_subscription(
            PointCloud2,
            '/unilidar/cloud',  # The topic name for lidar point cloud data
            self.point_cloud_callback,
            10
        )

        self.imu_subscriber = self.create_subscription(
            Imu,
            '/unilidar/imu',  # The topic name for IMU data
            self.imu_callback,
            10
        )

        # Open the log file in append mode (you can change the path as needed)
        self.log_filePC = open("./lidar_pointcloud_log.json", "w")
        self.log_fileIMU = open("./lidar_IMU_log.json", "w")


# {   "type": "LIDAR", 
#     "data": {   
#                 "orientation": {"x": 0.0010621061082929373, 
#                                 "y": -0.0034269997850060463, 
#                                 "z": 0.9877070188522339, 
#                                 "w": 0.1450851559638977}, 

#                 "angular_velocity": {"x": 0.0651683658361435, 
#                                      "y": 0.08855867385864258, 
#                                      "z": 0.012135538272559643}, 

#                 "linear_acceleration": {"x": 1.5113544464111328, 
#                                         "y": 1.9838787317276, 
#                                         "z": 7.249091625213623},

#                  "Point Cloud" : [{"x": 1.5113544464111328, 
#                                    "y": 1.9838787317276, 
#                                    "z": 7.249091625213623},

#                                   {"x": 1.5113544464111328, 
#                                    "y": 1.9838787317276, 
#                                    "z": 7.249091625213623},.........]
#              }
# }


    def point_cloud_callback(self, msg):
        # Extract and log point cloud data to JSON
        time.sleep(10) 
        self.get_logger().info('Received point cloud data')

        # Convert the PointCloud2 message to a list of points
        pc_data = pc2.read_points(msg, field_names=("x", "y", "z"), skip_nans=True)
        point_cloud = []
        for point in pc_data:
            point_cloud.append({
                'x': float(point[0]),
                'y': float(point[1]),
                'z': float(point[2])
            })

        # Prepare the JSON data to write
        log_entry = {
            'type': 'PointCloud2',
            'data': point_cloud
        }

        # Write the data to JSON file
        json.dump(log_entry, self.log_filePC)
        self.log_filePC.write("\n")
        

    def imu_callback(self, msg):
        # Extract and log IMU data to JSON
        # self.get_logger().info('Received IMU data')

        # with open("./lidar_IMU_log.json", "w") as file:
        #     hope = json.load(file)

        imu_data = {
            'orientation': {
                'x': msg.orientation.x,
                'y': msg.orientation.y,
                'z': msg.orientation.z,
                'w': msg.orientation.w
            },
            'angular_velocity': {
                'x': msg.angular_velocity.x,
                'y': msg.angular_velocity.y,
                'z': msg.angular_velocity.z
            },
            'linear_acceleration': {
                'x': msg.linear_acceleration.x,
                'y': msg.linear_acceleration.y,
                'z': msg.linear_acceleration.z
            }
        }

        # Prepare the JSON data to write
        log_entry = {
            'type': 'IMU',
            'data': imu_data
        }

        # Write the data to JSON file
        json.dump(log_entry, self.log_fileIMU)
        self.log_fileIMU.write("\n")
        time.sleep(5) 
    

    def __del__(self):
        # Close the log file when the node is destroyed
        self.log_filePC.close()
        self.log_fileIMU.close()

    # def convert_to_native_types(self, data):
    #     if isinstance(data, list):
    #         return [self.convert_to_native_types(item) for item in data]
    #     elif isinstance(data, tuple):
    #         return tuple(self.convert_to_native_types(item) for item in data)
    #     elif isinstance(data, np.float32):
    #         return float(data)  # Convert to native float
    #     else:
    #         return data  # Return other types as is


def main(args=None):
    rclpy.init(args=args)

    lidar_data_logger = LidarDataLogger()

    rclpy.spin(lidar_data_logger)

    lidar_data_logger.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
